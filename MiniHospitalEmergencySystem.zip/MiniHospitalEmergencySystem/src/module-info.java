/**
 * 
 */
/**
 * 
 */
module MiniHospitalEmergencySystem {
}