package Hospital;

public class Visit {

    private String visitId;
    private String date;
    private String doctor;
    private String diagnosis;
    private String treatment;

    private Visit next;

    public Visit(String visitId, String date, String doctor,
                 String diagnosis, String treatment) {

        this.visitId = visitId;
        this.date = date;
        this.doctor = doctor;
        this.diagnosis = diagnosis;
        this.treatment = treatment;

        this.next = null;
    }

    public String getVisitId() {
        return visitId;
    }

    public Visit getNext() {
        return next;
    }

    public void setNext(Visit next) {
        this.next = next;
    }

    public void display() {

        System.out.println("----------------------------");
        System.out.println("Visit ID: " + visitId);
        System.out.println("Date: " + date);
        System.out.println("Doctor: " + doctor);
        System.out.println("Diagnosis: " + diagnosis);
        System.out.println("Treatment: " + treatment);
        System.out.println("----------------------------");
    }
}