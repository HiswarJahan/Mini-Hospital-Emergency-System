 package Hospital;

import java.util.Scanner;

public class Main {

    static Scanner scanner = new Scanner(System.in);

    static PatientBST patientBST = new PatientBST();
    static EmergencyQueue emergencyQueue = new EmergencyQueue();
    static TreatmentStack treatmentStack = new TreatmentStack();

    public static void main(String[] args) {

        int choice;

        do {

            System.out.println("\n======================================");
            System.out.println("    MINI HOSPITAL EMERGENCY SYSTEM");
            System.out.println("======================================");

            System.out.println("1. Register Patient");
            System.out.println("2. Search Patient");
            System.out.println("3. Delete Patient");
            System.out.println("4. Display All Patients");

            System.out.println("5. Add Emergency Patient");
            System.out.println("6. Treat Emergency Patient");
            System.out.println("7. Display Emergency Queue");

            System.out.println("8. Add Treatment");
            System.out.println("9. Remove Latest Treatment");
            System.out.println("10. Display Treatment History");

            System.out.println("11. Add Patient Visit");
            System.out.println("12. Display Patient Visits");
            System.out.println("13. Search Patient Visit");
            System.out.println("14. Remove Patient Visit");

            System.out.println("0. Exit");

            System.out.println("======================================");

            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {

                case 1:
                    registerPatient();
                    break;

                case 2:
                    searchPatient();
                    break;

                case 3:
                    deletePatient();
                    break;

                case 4:
                    displayPatients();
                    break;

                case 5:
                    addEmergencyPatient();
                    break;

                case 6:
                    treatEmergencyPatient();
                    break;

                case 7:
                    displayEmergencyQueue();
                    break;

                case 8:
                    addTreatment();
                    break;

                case 9:
                    removeTreatment();
                    break;

                case 10:
                    displayTreatments();
                    break;

                case 11:
                    addVisit();
                    break;

                case 12:
                    displayVisits();
                    break;

                case 13:
                    searchVisit();
                    break;

                case 14:
                    removeVisit();
                    break;

                case 0:
                    System.out.println(
                            "Thank you for using the Hospital System!"
                    );
                    break;

                default:
                    System.out.println(
                            "Invalid choice. Please try again."
                    );
            }

        } while (choice != 0);

        scanner.close();
    }

    // ==========================================
    // REGISTER PATIENT
    // ==========================================

    static void registerPatient() {

        System.out.println("\n--- Register Patient ---");

        System.out.print("Enter Patient ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter Patient Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Age: ");
        int age = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter Contact: ");
        String contact = scanner.nextLine();

        System.out.print("Enter Medical Condition: ");
        String condition = scanner.nextLine();

        Patient patient = new Patient(
                id,
                name,
                age,
                contact,
                condition
        );

        patientBST.insert(patient);

        System.out.println("Patient registered successfully.");
    }

    // ==========================================
    // SEARCH PATIENT
    // ==========================================

    static void searchPatient() {

        System.out.println("\n--- Search Patient ---");

        System.out.print("Enter Patient ID: ");
        int id = scanner.nextInt();

        Patient patient = patientBST.search(id);

        if (patient != null) {

            System.out.println("\nPatient Found:");
            patient.display();

        } else {

            System.out.println("Patient not found.");
        }
    }

    // ==========================================
    // DELETE PATIENT
    // ==========================================

    static void deletePatient() {

        System.out.println("\n--- Delete Patient ---");

        System.out.print("Enter Patient ID: ");
        int id = scanner.nextInt();

        patientBST.delete(id);
    }

    // ==========================================
    // DISPLAY PATIENTS
    // ==========================================

    static void displayPatients() {

        System.out.println("\n--- Patient Records ---");

        patientBST.inOrder();
    }

    // ==========================================
    // ADD EMERGENCY PATIENT
    // ==========================================

    static void addEmergencyPatient() {

        System.out.println("\n--- Add Emergency Patient ---");

        System.out.print("Enter Patient ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter Patient Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Age: ");
        int age = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter Contact: ");
        String contact = scanner.nextLine();

        System.out.print("Enter Medical Condition: ");
        String condition = scanner.nextLine();

        Patient patient = new Patient(
                id,
                name,
                age,
                contact,
                condition
        );

        emergencyQueue.enqueue(patient);
    }

    // ==========================================
    // TREAT EMERGENCY PATIENT
    // ==========================================

    static void treatEmergencyPatient() {

        System.out.println("\n--- Treat Emergency Patient ---");

        Patient patient = emergencyQueue.dequeue();

        if (patient != null) {

            System.out.println("Now treating:");
            patient.display();

        } else {

            System.out.println("Emergency queue is empty.");
        }
    }

    // ==========================================
    // DISPLAY EMERGENCY QUEUE
    // ==========================================

    static void displayEmergencyQueue() {

        System.out.println("\n--- Emergency Queue ---");

        emergencyQueue.display();
    }

    // ==========================================
    // ADD TREATMENT
    // ==========================================

    static void addTreatment() {

        System.out.println("\n--- Add Treatment ---");

        System.out.print("Enter treatment: ");
        String treatment = scanner.nextLine();

        treatmentStack.push(treatment);

        System.out.println("Treatment added successfully.");
    }

    // ==========================================
    // REMOVE TREATMENT
    // ==========================================

    static void removeTreatment() {

        System.out.println("\n--- Remove Latest Treatment ---");

        String treatment = treatmentStack.pop();

        if (treatment != null) {

            System.out.println(
                    "Removed treatment: " + treatment
            );

        } else {

            System.out.println(
                    "Treatment history is empty."
            );
        }
    }

    // ==========================================
    // DISPLAY TREATMENTS
    // ==========================================

    static void displayTreatments() {

        System.out.println("\n--- Treatment History ---");

        treatmentStack.display();
    }

    // ==========================================
    // ADD VISIT
    // ==========================================

    static void addVisit() {

        System.out.println("\n--- Add Patient Visit ---");

        System.out.print("Enter Patient ID: ");
        int patientId = scanner.nextInt();
        scanner.nextLine();

        Patient patient = patientBST.search(patientId);

        if (patient == null) {

            System.out.println("Patient not found.");
            return;
        }

        System.out.print("Enter Visit ID: ");
        String visitId = scanner.nextLine();

        System.out.print("Enter Date: ");
        String date = scanner.nextLine();

        System.out.print("Enter Doctor: ");
        String doctor = scanner.nextLine();

        System.out.print("Enter Diagnosis: ");
        String diagnosis = scanner.nextLine();

        System.out.print("Enter Treatment: ");
        String treatment = scanner.nextLine();

        Visit visit = new Visit(
                visitId,
                date,
                doctor,
                diagnosis,
                treatment
        );

        patient.addVisit(visit);

        System.out.println("Visit added successfully.");
    }

    // ==========================================
    // DISPLAY VISITS
    // ==========================================

    static void displayVisits() {

        System.out.println("\n--- Patient Visit History ---");

        System.out.print("Enter Patient ID: ");
        int patientId = scanner.nextInt();

        Patient patient = patientBST.search(patientId);

        if (patient == null) {

            System.out.println("Patient not found.");
            return;
        }

        patient.displayVisits();
    }

    // ==========================================
    // SEARCH VISIT
    // ==========================================

    static void searchVisit() {

        System.out.println("\n--- Search Patient Visit ---");

        System.out.print("Enter Patient ID: ");
        int patientId = scanner.nextInt();
        scanner.nextLine();

        Patient patient = patientBST.search(patientId);

        if (patient == null) {

            System.out.println("Patient not found.");
            return;
        }

        System.out.print("Enter Visit ID: ");
        String visitId = scanner.nextLine();

        patient.searchVisit(visitId);
    }

    // ==========================================
    // REMOVE VISIT
    // ==========================================

    static void removeVisit() {

        System.out.println("\n--- Remove Patient Visit ---");

        System.out.print("Enter Patient ID: ");
        int patientId = scanner.nextInt();
        scanner.nextLine();

        Patient patient = patientBST.search(patientId);

        if (patient == null) {

            System.out.println("Patient not found.");
            return;
        }

        System.out.print("Enter Visit ID: ");
        String visitId = scanner.nextLine();

        patient.removeVisit(visitId);
    }
}