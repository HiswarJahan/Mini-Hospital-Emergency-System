package Hospital;

	public class Patient {

	    private int patientId;
	    private String name;
	    private int age;
	    private String contact;
	    private String medicalCondition;

	    // Head of singly linked list for visits
	    private Visit visitHead;

	    public Patient(int patientId, String name, int age,
	                   String contact, String medicalCondition) {

	        this.patientId = patientId;
	        this.name = name;
	        this.age = age;
	        this.contact = contact;
	        this.medicalCondition = medicalCondition;
	        this.visitHead = null;
	    }

	    public int getPatientId() {
	        return patientId;
	    }

	    public String getName() {
	        return name;
	    }

	    public int getAge() {
	        return age;
	    }

	    public String getContact() {
	        return contact;
	    }

	    public String getMedicalCondition() {
	        return medicalCondition;
	    }

	    public void display() {

	        System.out.println("----------------------------");
	        System.out.println("Patient ID: " + patientId);
	        System.out.println("Name: " + name);
	        System.out.println("Age: " + age);
	        System.out.println("Contact: " + contact);
	        System.out.println("Medical Condition: " + medicalCondition);
	        System.out.println("----------------------------");
	    }

	    // =========================
	    // ADD VISIT
	    // =========================

	    public void addVisit(Visit visit) {

	        if (visitHead == null) {
	            visitHead = visit;
	        } else {

	            Visit current = visitHead;

	            while (current.getNext() != null) {
	                current = current.getNext();
	            }

	            current.setNext(visit);
	        }
	    }

	    // =========================
	    // DISPLAY VISITS
	    // =========================

	    public void displayVisits() {

	        if (visitHead == null) {
	            System.out.println("No visit history found.");
	            return;
	        }

	        Visit current = visitHead;

	        while (current != null) {

	            current.display();

	            current = current.getNext();
	        }
	    }

	    // =========================
	    // SEARCH VISIT
	    // =========================

	    public void searchVisit(String visitId) {

	        Visit current = visitHead;

	        while (current != null) {

	            if (current.getVisitId().equals(visitId)) {

	                System.out.println("Visit found:");
	                current.display();
	                return;
	            }

	            current = current.getNext();
	        }

	        System.out.println("Visit not found.");
	    }

	    // =========================
	    // REMOVE VISIT
	    // =========================

	    public void removeVisit(String visitId) {

	        if (visitHead == null) {
	            System.out.println("No visit history found.");
	            return;
	        }

	        if (visitHead.getVisitId().equals(visitId)) {

	            visitHead = visitHead.getNext();

	            System.out.println("Visit removed successfully.");
	            return;
	        }

	        Visit current = visitHead;

	        while (current.getNext() != null) {

	            if (current.getNext().getVisitId().equals(visitId)) {

	                current.setNext(current.getNext().getNext());

	                System.out.println("Visit removed successfully.");
	                return;
	            }

	            current = current.getNext();
	        }

	        System.out.println("Visit not found.");
	    }
	}

