package Hospital;

import java.util.Stack;

public class TreatmentStack {

    private Stack<String> stack;

    public TreatmentStack() {

        stack = new Stack<>();
    }

    // =========================
    // PUSH
    // =========================

    public void push(String treatment) {

        stack.push(treatment);
    }

    // =========================
    // POP
    // =========================

    public String pop() {

        if (stack.isEmpty()) {

            return null;
        }

        return stack.pop();
    }

    // =========================
    // DISPLAY
    // =========================

    public void display() {

        if (stack.isEmpty()) {

            System.out.println("Treatment history is empty.");
            return;
        }

        System.out.println("Treatment History:");

        for (int i = stack.size() - 1; i >= 0; i--) {

            System.out.println(
                    (stack.size() - i) +
                    ". " +
                    stack.get(i)
            );
        }
    }
}