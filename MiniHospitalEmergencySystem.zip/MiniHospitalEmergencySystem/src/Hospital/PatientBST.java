package Hospital;

public class PatientBST {

    private class Node {

        Patient patient;
        Node left;
        Node right;

        Node(Patient patient) {

            this.patient = patient;
            left = null;
            right = null;
        }
    }

    private Node root;

    public PatientBST() {
        root = null;
    }

    // =========================
    // INSERT
    // =========================

    public void insert(Patient patient) {

        root = insertRecursive(root, patient);
    }

    private Node insertRecursive(Node root, Patient patient) {

        if (root == null) {
            return new Node(patient);
        }

        if (patient.getPatientId() < root.patient.getPatientId()) {

            root.left = insertRecursive(root.left, patient);

        } else if (patient.getPatientId() > root.patient.getPatientId()) {

            root.right = insertRecursive(root.right, patient);

        } else {

            System.out.println("Patient ID already exists.");
        }

        return root;
    }

    // =========================
    // SEARCH
    // =========================

    public Patient search(int patientId) {

        Node result = searchRecursive(root, patientId);

        if (result != null) {
            return result.patient;
        }

        return null;
    }

    private Node searchRecursive(Node root, int patientId) {

        if (root == null) {
            return null;
        }

        if (patientId == root.patient.getPatientId()) {
            return root;
        }

        if (patientId < root.patient.getPatientId()) {

            return searchRecursive(root.left, patientId);

        } else {

            return searchRecursive(root.right, patientId);
        }
    }

    // =========================
    // DELETE
    // =========================

    public void delete(int patientId) {

        if (search(patientId) == null) {

            System.out.println("Patient not found.");
            return;
        }

        root = deleteRecursive(root, patientId);

        System.out.println("Patient deleted successfully.");
    }

    private Node deleteRecursive(Node root, int patientId) {

        if (root == null) {
            return null;
        }

        if (patientId < root.patient.getPatientId()) {

            root.left = deleteRecursive(root.left, patientId);

        } else if (patientId > root.patient.getPatientId()) {

            root.right = deleteRecursive(root.right, patientId);

        } else {

            // No child
            if (root.left == null && root.right == null) {
                return null;
            }

            // Right child
            if (root.left == null) {
                return root.right;
            }

            // Left child
            if (root.right == null) {
                return root.left;
            }

            // Two children
            Node successor = findMinimum(root.right);

            root.patient = successor.patient;

            root.right = deleteRecursive(
                    root.right,
                    successor.patient.getPatientId()
            );
        }

        return root;
    }

    private Node findMinimum(Node root) {

        Node current = root;

        while (current.left != null) {
            current = current.left;
        }

        return current;
    }

    // =========================
    // IN-ORDER TRAVERSAL
    // =========================

    public void inOrder() {

        if (root == null) {

            System.out.println("No patients registered.");
            return;
        }

        inOrderRecursive(root);
    }

    private void inOrderRecursive(Node root) {

        if (root != null) {

            inOrderRecursive(root.left);

            root.patient.display();

            inOrderRecursive(root.right);
        }
    }
}