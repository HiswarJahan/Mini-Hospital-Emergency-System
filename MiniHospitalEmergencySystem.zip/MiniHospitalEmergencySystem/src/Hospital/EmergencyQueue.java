package Hospital;

import java.util.LinkedList;
import java.util.Queue;

public class EmergencyQueue {

    private Queue<Patient> queue;

    public EmergencyQueue() {

        queue = new LinkedList<>();
    }

    // =========================
    // ENQUEUE
    // =========================

    public void enqueue(Patient patient) {

        queue.add(patient);

        System.out.println(
                patient.getName() +
                " added to emergency queue."
        );
    }

    // =========================
    // DEQUEUE
    // =========================

    public Patient dequeue() {

        if (queue.isEmpty()) {

            return null;
        }

        return queue.poll();
    }

    // =========================
    // DISPLAY QUEUE
    // =========================

    public void display() {

        if (queue.isEmpty()) {

            System.out.println("Emergency queue is empty.");
            return;
        }

        System.out.println("Patients waiting for emergency treatment:");

        for (Patient patient : queue) {

            System.out.println(
                    "ID: " +
                    patient.getPatientId() +
                    " | Name: " +
                    patient.getName()
            );
        }
    }
}